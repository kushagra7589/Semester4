/*
    Author: Pulkit Arora
*/

#include<bits/stdc++.h>

using namespace std;

#define ll long long int

ll const maxm = 1000+9;
ll const maxn = 1000+9;

ll dp[maxm+1][maxn];

ll count(ll S[], ll n, ll m)
{
    for(ll i = 0 ; i <= m ; i++)
    {
        for(ll j = 0 ; j < n ; j++)
        {
            dp[i][j] = (2e11);
        }
    }
    for(ll i=0; i<n; i++)
    {
        dp[0][i] = 0;
    }

    for(ll i = 1; i < m+1; i++)
    {
        for(ll j = 0; j < n; j++)
        {
            dp[i][j] = (i-S[j] >= 0)?min(dp[i][j],1+dp[i-S[j]][j]):dp[i][j];
            dp[i][j] = (j >= 1)?min(dp[i][j],dp[i][j-1]):dp[i][j];
        }
    }
    return dp[m][n-1];
}
 
int main()
{
    ll M, N;
    cin>>M;
    cin>>N;
    ll ar[N];
    for(ll i = 0 ; i < N ; i++)
    {
        cin>>ar[i];
    }
    ll ans = count(ar, N, M);
    if(ans < 2e11)
    {
        cout<<ans<<endl;
    }
    else
    {
        cout<<-1<<endl;
    }
    return 0;
}