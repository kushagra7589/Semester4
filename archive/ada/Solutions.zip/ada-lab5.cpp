/*
	author : Magus Verma (magus12141@iiitd.ac.in)
	purpose : IIIT-Delhi ADA Course Lab 5 Solution
*/

#include <bits/stdc++.h>
#define ll long long

using namespace std;

int main(){
	ll n;
	cin>>n;
	
	ll week_wages[n][3]; 
	// [i][0] : wage for no work in week i
	// [i][1] : wage for low work in week i
	// [i][2] : wage for high work in week i
	
	for (int i = 0; i < n; ++i)
	{
		week_wages[i][0] = 0;
		cin>>week_wages[i][1]>>week_wages[i][2];
	}

	ll optimal_way[n][3][2];
	// [i][j][0]: optimal/maximum money possible by week i, doing j'th task in week i
	// [i][j][1]: storing solution parent, came from [i-i][j-([i][j][1]/3)][[i][j][1]%3]

	for (int j = 0; j < 3; ++j)
	{
		optimal_way[0][j][0] = week_wages[0][j];
		optimal_way[0][j][1] = -1; 
	}

	for (int i = 1; i < n; ++i)
	{
		for (int j = 0; j < 3; ++j)
		{
			ll ways[3]= {-1,-1,-1};
			ll best_way = -1, best_backtrack = -1;
			int this_week_work_type = j;
			for (int previous_week_work_type = 0; previous_week_work_type < 3; ++previous_week_work_type)
			{
				if(this_week_work_type == 2){
					if(i==1){
						ways[previous_week_work_type] = week_wages[i][2];
					}else{
						ways[previous_week_work_type] = 
							optimal_way[i-2][previous_week_work_type][0] + week_wages[i][2];
					}
				}else{
					ways[previous_week_work_type] = 
					optimal_way[i-1][previous_week_work_type][0] + week_wages[i][this_week_work_type];
				}
				if (best_way <= ways[previous_week_work_type]){
					best_way = ways[previous_week_work_type];
					best_backtrack = previous_week_work_type;
					if(this_week_work_type==2)best_backtrack +=3; 
				}
			}
			optimal_way[i][j][0] = best_way; 
			optimal_way[i][j][1] = best_backtrack;
		}
	}
	
	// To debug DP:
	// for (int i = 0; i < n; ++i)
	// {
	// 	for (int j = 0; j < 3; ++j)
	// 	{
	// 		cout<<optimal_way[i][j][0]<<","<<optimal_way[i][j][1]<<"\t";
	// 	}
	// 	cout<<endl;
	// }

	ll ans = -1, best_last_week = -1;
	for (int i = 0; i < 3; ++i)
	{
		if(ans < optimal_way[n-1][i][0]){
			ans = optimal_way[n-1][i][0];
			best_last_week = i;
		}
	}

	cout<<optimal_way[n-1][best_last_week][0]<<endl;

	string soln = "";
	if(best_last_week == 0) soln += "-";
	if(best_last_week == 1) soln += "l";
	if(best_last_week == 2) soln += "h";
	
	best_last_week = optimal_way[n-1][best_last_week][1];
	ll current_week = n-2;
	
	while(current_week>=0){
		if(best_last_week/3){
			soln += "-";
			best_last_week-=3;
		}else{
			if(best_last_week == 0) soln += "-";
			if(best_last_week == 1) soln += "l";
			if(best_last_week == 2) soln += "h";
			best_last_week = optimal_way[current_week][best_last_week][1];
		}
		current_week--;
	}
	for (std::string::reverse_iterator rit=soln.rbegin(); rit!=soln.rend(); ++rit)
	    std::cout << *rit;
    return 0;
}
