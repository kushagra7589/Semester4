#include <bits/stdc++.h>

using namespace std;

#define ll long long int

ll findLargestNotMoreThanA(vector<ll> &array, ll A, ll begin, ll end)
{
	ll pos = -1;
	while(begin<=end)
	{
		ll mid = (begin+end)/2;
		if(array[mid]>A)
		{
			end = mid - 1;
		}
		else
		{
			pos = mid;
			begin = mid+1;
		}
	}
	return pos;
}

ll smallestLargerThanA(vector<ll> &array, ll A, ll begin, ll end)
{
	ll pos = -1;
	while(begin<=end)
	{
		ll mid = (begin+end)/2;
		if(array[mid]>A)
		{
			pos = mid;
			end = mid - 1;
		}
		else
		{
			begin = mid + 1;
		}
	}
	return pos;
}

ll kthSmallest(vector<ll> arrays[], ll k, ll startIndex[], ll endIndex[])
{
	
	ll maxSize = 0, maxInd = 0;
	for(ll i = 0 ; i < 5 ; i++)
	{
		ll sizeAr = (endIndex[i]-startIndex[i]+1);
		if(sizeAr > maxSize)
		{
			maxSize = sizeAr;
			maxInd = i;
		}
	}	
	if(maxSize==1)
	{
		vector<ll> allElems;
		for(ll i = 0 ; i < 5; i++)
		{
			for(ll j = startIndex[i] ; j<= endIndex[i] ; j++)
				allElems.push_back(arrays[i][j]);
		}
		sort(allElems.begin(), allElems.end());
		return allElems[k-1];
	}
	ll midElementOfLargestArray = arrays[maxInd][(endIndex[maxInd]+startIndex[maxInd])/2];
	// cout<<"Maximum size: "<<maxSize<<" Mid of Largest: "<<midElementOfLargestArray<<endl;
		
	ll indicesNotGreaterThanM[5];
	ll firstIndexGreaterThanM[5];
	ll totalElementsLessThanEqM = 0;
	for(ll i = 0 ; i < 5 ; i++)
	{
		indicesNotGreaterThanM[i] = findLargestNotMoreThanA(arrays[i], midElementOfLargestArray, startIndex[i], endIndex[i]);
		firstIndexGreaterThanM[i] = smallestLargerThanA(arrays[i], midElementOfLargestArray, startIndex[i], endIndex[i]);
		if(indicesNotGreaterThanM[i]!=-1) 
			totalElementsLessThanEqM+=(indicesNotGreaterThanM[i] - startIndex[i]+1);
		// cout<<i<<" Not > M: "<<indicesNotGreaterThanM[i]<<" totalElementsLessThanEqM: "<<totalElementsLessThanEqM<<endl;
	}

	if(totalElementsLessThanEqM == k)
		return midElementOfLargestArray;
	else if(k < totalElementsLessThanEqM )
	{
		ll newStartIndex[5], newEndIndex[5];
		for(ll i = 0 ; i < 5 ; i++)
		{
			if(startIndex[i] > endIndex[i])
			{
				newStartIndex[i] = startIndex[i];
				newEndIndex[i] = endIndex[i];
			}
			else
			{
				newStartIndex[i] = startIndex[i];
				newEndIndex[i] = (indicesNotGreaterThanM[i]==-1)?(startIndex[i]-1):indicesNotGreaterThanM[i];
			}
		}
		// cout<<"In ELSEIF with "<<k<<endl;
		// for(ll i = 0 ; i < 5 ; i++)
		// {
		// 	cout<<i<<": startIndex: "<<newStartIndex[i]<<" endIndex: "<<newEndIndex[i]<<endl;
		// }
		return kthSmallest(arrays, k, newStartIndex, newEndIndex);
	}
	else
	{
		ll newStartIndex[5], newEndIndex[5];
		for(ll i = 0 ; i < 5 ; i++)
		{
			// newStartIndex[i] = indicesNotGreaterThanM[i] + 1;
			// if(indicesNotGreaterThanM[i]==-1 && )
			// 	newStartIndex[i] = endIndex[i]+1;
			// newEndIndex[i] = endIndex[i];
			if(startIndex[i]>endIndex[i])
			{
				newStartIndex[i] = startIndex[i];
				newEndIndex[i] = endIndex[i];
			}
			else
			{
				if(firstIndexGreaterThanM[i]==-1)
				{
					newStartIndex[i] = endIndex[i]+1;
					newEndIndex[i] = endIndex[i];
				}
				else
				{
					newStartIndex[i] = firstIndexGreaterThanM[i];
					newEndIndex[i] = endIndex[i];
				}
			}
		}
		// cout<<"In ELSE with "<<( k-totalElementsLessThanEqM)<<endl;
		// for(ll i = 0 ; i < 5 ; i++)
		// {
		// 	cout<<i<<": startIndex: "<<newStartIndex[i]<<" endIndex: "<<newEndIndex[i]<<endl;
		// }
		return kthSmallest(arrays, k-totalElementsLessThanEqM, newStartIndex, newEndIndex);
	}
}
int main()
{
	// vector<ll> ar[5];
	// for(ll i = 0 ; i < 30; i++)
	// {
	// 	ar[i/6].push_back(i);
	// }
	// ar[0][5] = 33;
	// ll startIndices[] = {0,0,0,0,0};
	// ll endIndices[] = {5,5,5,5,5};
	
	// cout<<kthSmallest(ar, 25, startIndices, endIndices)<<endl;
	ll n,q;
	cin>>n>>q;
	vector<ll> ar[5];
	for(ll i = 0 ; i < n ; i++)
	{
		ll a, b, c, d, e;
		cin>>a>>b>>c>>d>>e;
		ar[0].push_back(a); ar[1].push_back(b); ar[2].push_back(c); ar[3].push_back(d); ar[4].push_back(e);
	}
	for(ll i = 0 ; i < q ; i++)
	{
		ll st, end, k;
		cin>>st>>end>>k;
		ll startIndex[5];
		ll endIndex[5];
		for(ll i = 0 ; i < 5 ; i++)
		{
			startIndex[i] = st;
			endIndex[i] = end;
		}
		cout<<kthSmallest(ar, k, startIndex, endIndex)<<endl;
	}
}