#include<bits/stdc++.h>
using namespace std;
vector<int> string_to_int(string str) {
	vector<int> res;
	for(int i = 0; i < (int)(str.length()); ++i) {
		res.push_back(str[i] - '0');
	}
	return res;
}
vector<int> addition(vector<int> &v1, vector<int> &v2) {
	int lena = v1.size();
	int lenb = v2.size();
	if(lena < lenb) {
		swap(v1, v2);
		swap(lena, lenb);
	}
	int carry = 0;
	vector<int> res;
	for(int idxa = lena - 1, idxb = lenb - 1; idxa >= 0; --idxa, --idxb) {
		int x = v1[idxa];
		int y = (idxb >= 0 ? v2[idxb] : 0);
		int sm = x + y + carry;
		carry = sm / 10;
		sm %= 10;
		res.push_back(sm);
	}
	if(carry) {
		res.push_back(carry);
	}
	reverse(res.begin(), res.end());
	return res;
}
vector<int> subtraction(vector<int> v1, vector<int> v2) {
	int lena = v1.size();
	int lenb = v2.size();
	int borrow = 0;
	vector<int> res;
	for(int idxa = lena - 1, idxb = lenb - 1; idxa >= 0; --idxa, --idxb) {
		int x = v1[idxa];
		int y = (idxb >= 0 ? v2[idxb] : 0);
		if(borrow) {
			x--;
		}
		int sm;
		if(x < y) {
			sm = x + 10 - y;
			borrow = 1;
		} else {
			sm = x - y;
			borrow = 0;
		}
		res.push_back(sm);
	}
	reverse(res.begin(), res.end());
	return res;
}
void pow10(vector<int>& a, int n) {
	int lena = a.size();
	if(lena == 1 && a[0] == 0) {
		return;
	}
	for(int i = lena; i < lena + n; ++i) {
		a.push_back(0);
	}
}
void make_equal_length(vector<int> &v1, vector<int> &v2) {
	reverse(v1.begin(), v1.end());
	reverse(v2.begin(), v2.end());
	while(v1.size() > v2.size()) {
		v2.push_back(0);
	}
	while(v1.size() < v2.size()) {
		v1.push_back(0);
	}
	reverse(v1.begin(), v1.end());
	reverse(v2.begin(), v2.end());
}
void karatsuba_multiplication(vector<int> &v1, vector<int>&v2, vector<int>&res) {
	make_equal_length(v1, v2);
	int len = v1.size();
	if(len == 1) {
		int val = v1[0] * v2[0];
		if(val < 10) {
			if(res.empty()) {
				res.push_back(val);
			} else {
				res[0] = val;
			}
		} else {
			if(res.empty()) {
				res.push_back(val / 10);
				res.push_back(val % 10);
			} else if((int)(res.size()) == 1) {
				res[0] = val / 10;
				res.push_back(val % 10);
			} else {
				res[0] = (val / 10);
				res[1] = val % 10;
			}
		}
	} else {
		int lftsz = len - (len / 2);
		vector<int> xl(v1.begin(), v1.begin() + lftsz);
		vector<int> xr(v1.begin() + lftsz, v1.end());
		vector<int> yl(v2.begin(), v2.begin() + lftsz);
		vector<int> yr(v2.begin() + lftsz, v2.end());

		int maxn = 3 * len;
		vector<int> p1;
		vector<int> p2;
		vector<int> p3;
		karatsuba_multiplication(xl, yl, p1);
		karatsuba_multiplication(xr, yr, p2);

		vector<int> tmp1 = addition(xl, xr);
		vector<int> tmp2 = addition(yl, yr);

		karatsuba_multiplication(tmp1, tmp2, p3);

		p3 = subtraction(p3, p1);
		p3 = subtraction(p3, p2);

		pow10(p3, len / 2);
		pow10(p1, 2 * (len / 2));
		
		res = addition(p1, p2);
		res = addition(res, p3);
		reverse(res.begin(), res.end());
		while(!res.empty() && res.back() == 0) {
			res.pop_back();
		}
		reverse(res.begin(), res.end());
	}
}
int main() {
	string str, str1;
	cin >> str >> str1;
	vector<int> a = string_to_int(str);
	vector<int> b = string_to_int(str1);
	vector<int> res;
	karatsuba_multiplication(a, b, res);
	for(int i = 0; i < (int)(res.size()); ++i) {
		cout << res[i];
	}
	cout << endl;
	return 0;
}