#include <bits/stdc++.h>

using namespace std;

#define ll long long int

ll const MAXN = 1000000+9;

ll ar[MAXN];

ll aux[MAXN];

ll countBridgeInversions(ll start, ll mid, ll end);

ll countInversions(ll start, ll end)
{
	if(start>=end)
	{
		return 0;
	}
	else
	{
		ll mid = (start+end)/2;
		ll leftSide = countInversions(start, mid);
		ll rightSide = countInversions(mid+1, end);
		ll bridges = countBridgeInversions(start, mid, end);
		return (leftSide+rightSide+bridges);
	}
}

ll countBridgeInversions(ll start, ll mid, ll end)
{
	ll inversions = 0;
	// ll aux[end - start + 1];
	ll currentLeft = start, currentRight = mid+1, currentAux = 0;
	while(currentLeft <= mid && currentRight <= end)
	{
		if(ar[currentLeft] < ar[currentRight])
		{
			aux[currentAux++] = ar[currentLeft++];
		}
		else
		{
			inversions += (mid - currentLeft + 1);
			aux[currentAux++] = ar[currentRight++];
		}
	}

	while(currentLeft <= mid)
	{
		aux[currentAux++] = ar[currentLeft++];
	}

	while(currentRight <= end)
	{
		aux[currentAux++] = ar[currentRight++];
	}

	for(ll i = start ; i <= end ; i++)
	{
		ar[i] = aux[i - start];
	}

	return inversions;
}

int main()
{
	// clock_t tStart = clock();
	// ll ar[] = {2, 1, 4, 3};
	ios_base::sync_with_stdio(false);
	ll n;
	cin>>n;
	// ll ar[n];
	for(ll i = 0 ; i < n ; i++)
	{
		cin>>ar[i];
	}
	cout<<countInversions(0, n-1)<<endl;
	// printf("Time taken: %.2fs\n", (double)(clock() - tStart)/CLOCKS_PER_SEC);
}